#include <iostream>
//--------------------ADDITIONS  NEEDED BY THE STUDENT  --------
//you need to add some preprocessor directives and maybe other items


//Please note that we have NOT used a main definition in this way yet,
//but this allows the program to use inputs from the command line
//as discussed in the lab description

int main(int argc, char * * argv) 
{

//--------------------ADDITION NEEDED BY THE STUDENT  --------
//PLease instantiate a Gantt object and call it Lab2GanttObject


   if (argc < 3)
      cout << "please specify an input file name and output html file name" << endl;
   else //there is a second string on the command line 
   {

      ifstream inputFile(argv[1], ios::in); //temporarily open file to see if valid

      if (!inputFile) //if inputFile is not valid then print error message
      {
         cout << "The input file does not exist!!" << endl;
      }
      else //if is valid
      {

         inputFile.close(); //close the file because it will be used later

         Lab2GanttObject.readInData(argv[1]); //This populates data from GantChart
         Lab2GanttObject.createHTMLFile(argv[2]);  //This creates the html file
      }

   }  //end of else statement
}
