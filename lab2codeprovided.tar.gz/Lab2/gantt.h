#include <iostream>
#include <fstream>
#include <string>
#include <vector>

// -----------------CHANGE NEEDED BY STUDENT ---------------
// I want you to change this struct to a c++ class
// with proper encapsulation, a constructor, and a full set
// of getters and setters. Please keep the class
// interface in this file AND put the implementations in 
// the gantt.cc file.

struct Task
{
    int taskNum; //Each task will have a unique number
    std::string taskLeader; //Assume leader name is one string john_smith
    int beginOnDay; //This is the start day i.e. start of day 5 for example
    int taskDuration; //This is the number of days to complete
    std::string taskDescription; //This will be a sentence describing task

};

class Gantt
{
   public:
   // -----------------ADDITION  NEEDED BY STUDENT ---------------
   // I would like for you to make constructor(s) for this class.
   // Please put the implementation in the gantt.cc file

      void readInData(std::string); //This will have the file name
      void createHTMLFile(std::string); //This will have the outputfile name

   private: //These will be utility files used internally on this object so I will keep them private

      void startHTMLfile();
      void endHTMLfile();
      void insertHead();
      void insertBody();
      void beginBody();
      void endBody();
      void ganttChartHeaderInfo();
      void chartColumnLabels();
      void ganttChartBody();
      void taskCharts();

   private:

       std::vector <Task> taskList; //notice this is a vector of your user-defined type Task
       std::string projectName; //Single string name for project
       std::string beginDate;   //This is a calendar data that is needed.. just read in as a string from input file
       int durationInWeeks; //assume that integral number by definition in the problem
       int numberOfTeamMembers; 
       std::vector <std::string> teamMembers;
       int numTasks;
       std::string outFileName; //This will be needed 

};
