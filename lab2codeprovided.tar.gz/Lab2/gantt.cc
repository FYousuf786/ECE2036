#include <iostream>
#include <fstream>

//------------------ ADDITION NEEDED BY STUDENT -----------------------
//There are some preprocessor directives that you will need here.


#define OFFSET 50
#define TABLE_OVERHEAD 6

using namespace std;

void Gantt::readInData(string inputFileName)
{
    //This member function will read in data from the input file that describes the project
    //The format of this file should be evident from the example input.txt provided to you.

    ifstream inFileObject(inputFileName.c_str(), ios::in); 
    string trash;

    inFileObject >> trash >> projectName;  //Assume project name is a single string! 
    inFileObject >> trash >> beginDate; 
    inFileObject  >> trash >> durationInWeeks; 
    inFileObject >> trash >> numberOfTeamMembers;

//------------------ ADDITION NEEDED BY STUDENT -----------------------
// Now that you know the numberOfTeamMembers you can read in data into the teamMembers vector
// using a looping structure









//------------------ CHANGE NEEDED BY STUDENT -----------------------
// This is the code using Task as a struct.  I would like you to 
// change this to work with your new Task class. Note that you
// might have to read into a temporary variable before using your
// set and get functions.
 
    inFileObject >> trash >> numTasks;

    taskList.resize(numTasks);
 
    for (int i = 0; i < numTasks; i++)
    {
       inFileObject >> trash >> taskList[i].taskNum;
       inFileObject >> trash >> taskList[i].taskLeader;
       inFileObject >> trash >> taskList[i].beginOnDay;
       inFileObject >> trash >> taskList[i].taskDuration;
       inFileObject >> trash; 

       getline(inFileObject, taskList[i].taskDescription);
    }
        
//-----------------------------------------

    inFileObject.close(); 
};

void Gantt::createHTMLFile(string outputFileName)
{
   //This function will create the output HTML file that will
   //represent your Gantt Chart. You will need to make sure
   //that you get all of these member functions working properly
   //in this skeleton code.  I broke the tasks into subtask to 
   //help make this member function easier to debug and understand.

   //NOTE you may have to comment these out as you get each 
   //one working!!! Remember the incremental design approach!

    outFileName = outputFileName; //This will be used often

    startHTMLfile();
    insertHead();
    beginBody();
    ganttChartHeaderInfo();
    chartColumnLabels();
    ganttChartBody();
    taskCharts();
    endBody();
    endHTMLfile();
   
}

void Gantt::insertHead()
{

    ofstream outputFileObject(outFileName.c_str(), ios::app);


    //------------------ ADDITION NEEDED BY STUDENT -----------------------
    //This member function will read in the file called
    // head.html and put the contents into the output file
    // that is being created. This should be a simple task
    // so I would like for you to complete this.  
    // For all your html files, the header will also be the
    // same. No need to change the html script, please just put this
    // in your output html file! You may hard code in the name of 
    // the head.html. Notethat this is one of the files that I 
    // have provided to you in the tarfile
     
  
    outputFileObject.close();
}


void Gantt::startHTMLfile()
{
    //You do not need to change this member function 

    ofstream outputFileObject(outFileName.c_str(), ios::out);
    outputFileObject << "<html>" << endl;
    outputFileObject.close();
}

void Gantt::endHTMLfile()
{
   //You do not need to change this member function 

    ofstream outputFileObject(outFileName.c_str(), ios::app);
    outputFileObject << "</html>" << endl;
    outputFileObject.close();
}

void Gantt::beginBody()
{
   //You do not need to change this member function 

    ofstream outputFileObject(outFileName.c_str(), ios::app);
    outputFileObject << "<body>" << endl;
    outputFileObject.close();
}

void Gantt::endBody()
{
   //You do not need to change this member function 

    ofstream outputFileObject(outFileName.c_str(), ios::app);
    outputFileObject << "</body>" << endl;
    outputFileObject.close();
}

void Gantt::ganttChartHeaderInfo()
{

    ofstream outputFileObject(outFileName.c_str(), ios::app);

    //------------------ CHANGE NEEDED BY STUDENT -----------------------
    // According to the specification of the lab the tableWidth should be numberofWeeks*210+50 to get good spacing

    int tableWidth; //initialize this with the formula as specified above 

    outputFileObject << "<table style=\"width: " << tableWidth << "px\">" << endl;

   //------------------ ADDITION NEEDED BY STUDENT -----------------------
   //I got you started. You finish the rest to create the top of the html page
   // Project Name: XXXX
   // Begin Date:  XXXX
   // Project Duration: XXXX
   // Team Members: XXXX





    outputFileObject.close();
}

void Gantt::chartColumnLabels()
{
   //This function will create the labels for the Gantt chart
   // Some of this is a little tedious, but I will get you started.
   // You may edit anything in the function if you feel it is necessary
   
    ofstream outputFileObject(outFileName.c_str(), ios::app);

    int tableWidth = 210* durationInWeeks + OFFSET;
   
   outputFileObject << "<tr> \n\t <td style = \"height: 30px;\">\n </td>\n</tr>\n" << endl;

   outputFileObject << "<td style=\"width: 50px; vertical-align: bottom; border: dotted 1px grey;\"> "
                    << "<b> Task Label </b> </td> " << endl;

   outputFileObject << "<td style=\"width:" << tableWidth-OFFSET+TABLE_OVERHEAD 
                    <<"px; vertical-align: bottom;\">" << endl;
 
   // The colspan needs to be the number of days each week 
   // The width of the nested table needs to be numWeeks*210px
   outputFileObject << "<table style=\"width: " << tableWidth-OFFSET+TABLE_OVERHEAD  
                    << "px; border: dotted 1px grey;\">" << endl;
   
   //First the headers for the number of weeks in your project 
   //For simplicity, assume that the number of weeks is ALWAYS a whole number
   outputFileObject << "<tr>";

   for (int i=1; i <= durationInWeeks; i++)
   {
      outputFileObject << "<td colspan=\"7\" style=\"text-align: center ; "
                       << "width:210px; border: solid 1px black;\">"
                       << "Week " << i << "</td>" << endl;
   } 
   outputFileObject << "</tr>";

//------------------ ADDITION NEEDED BY STUDENT -----------------------
// You will need to fill in the second part of this chart using
// days of the week.  Please use the format in the example HTML
// file (exampleGantt.html)  that I provided for you. You should easily
// see the pattern that you will need to replicate. You will need to use a looping 
// structure to complete.

   outputFileObject << "<tr>" <<endl;

   // Insert your code here! 





   outputFileObject << "</tr>";
   outputFileObject << "</table>";

   outputFileObject << "</td>";
   outputFileObject << "</tr>";

    outputFileObject.close();
}

void Gantt::ganttChartBody()
{
    ofstream outputFileObject(outFileName.c_str(), ios::app);

  //------------CHANGE NEEDED BY STUDENT-----
  // You will need to make this function work with your new Task Class.
  // Right now the struct has no encapsulation. 

   int i = 0;

   for (i=0; i < numTasks ; i++)
   {
      outputFileObject << "<tr>";
      outputFileObject <<"<td style=\"border:dotted 1px grey;\"> Task " << taskList[i].taskNum << "</td>" << endl;
      outputFileObject <<"<td style=\"border: dotted 1px grey;\">" << endl;
      outputFileObject << "<img src=\"dot_trans.gif\" height=\"15px;\" width=\""
                       << 30*(taskList[i].beginOnDay-1) << "px;\">" << endl;
    
      if (i%2 == 0) //then print gold
      { 
         outputFileObject << "<img src=\"gold.png\" height=\"15px;\" width=\""
                    << 30*taskList[i].taskDuration << "px;\">" << endl;
      }
      else
      {
         outputFileObject << "<img src=\"black.png\" height=\"15px;\" width=\""
                    << 30*taskList[i].taskDuration << "px;\">" << endl;
      }

      outputFileObject << "</td>";
      outputFileObject << "</tr>";
   }

   outputFileObject.close();

}


void Gantt::taskCharts()
{
   
    ofstream outputFileObject(outFileName.c_str(), ios::app);

    //------------------ ADDITION NEEDED BY STUDENT -----------------------
    // You will need to complete this function yourself.  You need
    // to create the lower table at the end of the html file.
    // Please see the example html file (exampleGantt.html) to figure this out!! 


    // Please NOTE that This lower table has the same width as the top table


    outputFileObject << "</table>" << endl; 

}



